package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.entity.Customer;
import com.training.service.CustomerService;
@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;
	@GetMapping("/read")
	public String greet() {
		return "read";
	}
	@GetMapping("/greet/{name}")
	public String greetWithName(@PathVariable("name") String name) {
		return "hello"+name;
	}
	
	//CRUD
	
	@GetMapping("/read/{id}")
	public Customer  getCustomer(@PathVariable("id") Integer id) {
		return customerService.readCustomer(id);
		
	} 
	@GetMapping("/readall")
	public List<Customer>  getCustomer() {
		return customerService.readAll();
		
	} 
	@PostMapping("/add")
	public String add(@RequestBody Customer customer) {
		return customerService.addCustomer(customer);
		
	}
	@PutMapping("/update")
	public String update(@RequestBody Customer customer) {
		return customerService.updateCustomer(customer.getId(),customer.getName());
		
	}
	@DeleteMapping("/delete/{id}")

	public String   deleteCustomer(@PathVariable("id") Integer id) {
		return customerService.deleteCustomer(id);
		
	}
	
	
	
}
