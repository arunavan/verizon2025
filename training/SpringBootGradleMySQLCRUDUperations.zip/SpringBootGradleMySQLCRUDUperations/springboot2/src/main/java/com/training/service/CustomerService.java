package com.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.training.entity.Customer;
import com.training.repo.CustomerRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	
	public Customer readCustomer(Integer id) {
		return customerRepository.findById(id).get();
	}
	public List<Customer> readAll() {
		return customerRepository.findAll();
	}
	
	public String addCustomer(Customer customer) {
		customerRepository.save(customer);
		return "Added";
	}
	
	public String updateCustomer(Integer id,String name) {
		Customer c= customerRepository.findById(id).get();
		c.setName(name);
		return "Updated";
	}
	
	public String deleteCustomer(Integer id) {
		 customerRepository.deleteById(id);
		 return "Deleted";
	}

}
