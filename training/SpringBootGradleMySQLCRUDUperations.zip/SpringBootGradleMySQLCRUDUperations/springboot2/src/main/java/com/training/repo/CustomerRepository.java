package com.training.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.entity.Customer;

public interface CustomerRepository  extends JpaRepository<Customer,Integer>{
	//save, delete,find,update

}
