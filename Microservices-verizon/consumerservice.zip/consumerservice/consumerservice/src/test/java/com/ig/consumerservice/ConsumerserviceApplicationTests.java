package com.ig.consumerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
