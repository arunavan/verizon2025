package com.verizon;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

public class SumTest {

  @Test
  public void addTest() {
	  Sum s=new Sum();
	  assertEquals(10,s.add(6,4));
	  assertEquals(11,s.add(6,4));
    //throw new RuntimeException("Test not implemented");
  }
}
