package com.verizon;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class CalculatorTest {
  @BeforeMethod
  public void beforeMethod() {
	  
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }


  @Test
  public void addTest() {
	  
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void divideTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void multiplyTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void subtractTest() {
    throw new RuntimeException("Test not implemented");
  }
}
