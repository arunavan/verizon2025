package com.verizon.tests;

import org.testng.Assert;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.verizon.Calculator;
public class CalculatorParamTest {
    @Test
    @Parameters({"a", "b"})
    public void testWithParameters( int a,  int b) {
        Calculator calc = new Calculator();
        Assert.assertEquals(calc.add(a, b), 50);
    }
}




// public void testWithParameters(@Optional("2") int a, @Optional("3") int b) {
