package com.verizon.tests;



import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.verizon.Calculator;

public class DataDrivenTest {
    @DataProvider(name = "addData")
    public Object[][] addData() {
        return new Object[][] {
            {1, 2, 3},
            {5, 7, 12},
            {0, 0, 0},
            {-1, 1, 0}
        };
    }

    @Test(dataProvider = "addData")
    public void testAddWithDataProvider(int a, int b, int expected) {
        Calculator calc = new Calculator();
        Assert.assertEquals(calc.add(a, b), expected);
    }
}