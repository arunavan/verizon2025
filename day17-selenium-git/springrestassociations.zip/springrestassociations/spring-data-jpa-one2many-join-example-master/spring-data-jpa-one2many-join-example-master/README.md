# spring-data-jpa-one2many-join-example
How to perform association mapping and join operation using spring data jpa
