package com.verizon.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.model.Course;

@RestController
public class CourseController {
	List<Course> courseList=
		 Arrays.asList(
				new Course(101,"java"),
				new Course(102,"oracle"),
				new Course(103,"python")
				
				);
	/*  request body
	 {
	    "id":"104",
		"name":"box"
      }
*/
	  @PostMapping("/course")
    public  Course addCourse(@RequestBody Course course) {
	  return course;
  }
	  @PutMapping("/course/{id}")
	    public  Course addCourse(@RequestBody Course course,@PathVariable Integer id) {
		  if(course.getId().equals(id))
			  course.setName("Oracle");
		  return course;
	  } 
	  @DeleteMapping("/delete/{id}")
	  public String deleteCourse(@PathVariable("id")Integer id) {
		  return "Course with "+id +" is deleted";
	  }
	  
	  @GetMapping("/course/{id}")
	  public Course getCourseById(@PathVariable("id")Integer id) {
		  Course c1=new Course();
		  for(Course c:courseList) {
			  if(c.getId().equals(id))
				  c1.setId(c.getId());
			      c1.setName(c.getName());
		  }
		  return c1;
	  }
	  
	  
	  
	  @GetMapping("/course")
	  public List<Course> getAllCourses() {
		  List<Course> c1=new ArrayList<>();
		  for(Course c:courseList) {
			  Course cc=new Course();
				  cc.setId(c.getId());
			      cc.setName(c.getName());
			      c1.add(cc);
		  }
		  return c1;
	  }
	  
	  
	
}
