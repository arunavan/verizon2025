package com.verizon.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	@GetMapping("/product") //http://localhost:8083/product?id=123
	public String message(@RequestParam("id") Integer id) {
		return "Product details of "+id;
	}
		
	@GetMapping("/product1/{id1}")// http://localhost:8083/product1/102
	public String message1(@PathVariable("id1") Integer id) {
		return "path param :"+id;
	}
	@GetMapping("/read")
	public String get() {
		return "get Method";
	}
	@PostMapping("/add")
	public String add() {
		return "post for adding new resource";
	}
	@PutMapping("/update")
	public String update() {
		return "put for update resource";
	}
	@DeleteMapping("/delete")
	public String delete() {
		return "delete for deleting resource";
	}
}
