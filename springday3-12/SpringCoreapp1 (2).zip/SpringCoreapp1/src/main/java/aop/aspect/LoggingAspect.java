package aop.aspect;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;
@Aspect
@Component
public class LoggingAspect {
    @Before("execution(* aop.service.UserService.*(..))")
    public void beforeAdvice(JoinPoint joinPoint) {
        System.out.println("→ [Before] " + joinPoint.getSignature().getName());
    }
    @After("execution(* aop.service.UserService.*(..))")
    public void afterAdvice(JoinPoint joinPoint) {
        System.out.println("← [After] " + joinPoint.getSignature().getName());
    }
    @AfterReturning(pointcut = "execution(* aop.service.UserService.getUser(..))", returning = "result")
    public void afterReturningAdvice(Object result) {
        System.out.println("[AfterReturning] Returned: " + result);
    }
    @AfterThrowing(pointcut = "execution(* aop.service.UserService.causeError(..))", throwing = "ex")
    public void afterThrowingAdvice(Exception ex) {
        System.out.println("[AfterThrowing] Exception caught: " + ex.getMessage());
    }
}

