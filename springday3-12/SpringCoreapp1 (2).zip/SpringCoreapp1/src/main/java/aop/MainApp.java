package aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aop.config.AppConfig;
import aop.service.UserService;


public class MainApp {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        UserService userService = context.getBean(UserService.class);

        userService.addUser("Verizonuser");
        userService.deleteUser("Verizonuser");

        String user = userService.getUser();
        System.out.println("Returned from getUser(): " + user);

        try {
            userService.causeError();
        } catch (Exception e) {
            System.out.println("Caught exception in Main: " + e.getMessage());
        }
    }
}