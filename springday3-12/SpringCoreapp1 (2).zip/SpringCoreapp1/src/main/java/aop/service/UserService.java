package aop.service;
import org.springframework.stereotype.Component;

@Component
public class UserService {

    public void addUser(String name) {
        System.out.println("Adding user: " + name);
    }
    public void deleteUser(String name) {
        System.out.println("Deleting user: " + name);
    }
    public String getUser() {
        return "User details";
    }
    public void causeError() {
        throw new RuntimeException("Simulated error");
    }
}

