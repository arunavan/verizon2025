package springjdbc;



import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import springjdbc.config.AppConfg;
import springjdbc.dao.UserDao;
import springjdbc.model.User;
public class MainApp {
    public static void main(String[] args) {
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfg.class);

    	
    	UserDao userDao = context.getBean(UserDao.class);
        userDao.createTable();
        userDao.insert(new User(1, "VErizonuser1"));
        userDao.insert(new User(2, "verizonuser2"));
        List<User> users = userDao.findAll();
        users.forEach(System.out::println);
    }
}