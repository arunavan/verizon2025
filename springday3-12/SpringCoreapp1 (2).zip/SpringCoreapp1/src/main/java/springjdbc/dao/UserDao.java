package springjdbc.dao;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import springjdbc.model.User;

public class UserDao {
    private final JdbcTemplate jdbcTemplate;
   

    public UserDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public void createTable() {
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS users (id INT PRIMARY KEY, name VARCHAR(100))");
    }

    public void insert(User user) {
        jdbcTemplate.update("INSERT INTO users (id, name) VALUES (?, ?)", user.getId(), user.getName());
    }

    public List<User> findAll() {
        return jdbcTemplate.query("SELECT * FROM users",new UserMapper() );
    }
	/*
	 * public User findUserById(int id,) { return
	 * jdbcTemplate.query("SELECT * FROM users where id=?",new UserMapper() ); }
	 */
   
}
