package com.verizon;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.verizon.controller.CustomerController;
import com.verizon.service.CustomerService;

//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
      //  Customer c=new Customer();
      //  System.out.println(c.getId()+"  "+c.getName());
        //IOC container
    //	ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
    	AnnotationConfigApplicationContext context=
    			new AnnotationConfigApplicationContext(SpringConfig1.class);
    	CustomerService cs=(CustomerService)context.getBean("customerService");
    	cs.getCustomerDetails();
    	CustomerController cc=(CustomerController)context.getBean("customerController");
    	cc.show();
    //	Customer c1=(Customer)context.getBean("customer");
    //    Customer c2=(Customer)context.getBean(Customer.class);
    //    System.out.println(c1);
    //    System.out.println(c2);
      
    //    Account a1=(Account)context.getBean("account");
    //    System.out.println(a1);
      //  context.stop();
       context.close(); 
      //  context.
        
    }
}
