package com.verizon;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.verizon.service com.verizon.controller")
public class SpringConfig1 {
	

}
