package com.verizon.service;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

@Component
public class CustomerService// implements InitializingBean
{
	
	public void getCustomerDetails() {
		System.out.println(" banking service- deposit");
	}
	
	public void afterPropertiesSet() {
		System.out.println("properties set");
	}
	public void postConstruct() {
		System.out.println(" object construction");
	}

	public void preDestroy() {
		System.out.println(" object destruction");
	}
}
