package com.veri.autowiring.service;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import springjdbc.config.AppConfg;

public class AutowiringDemo {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfg.class);

	    VehicleService vs=context.getBean(VehicleService.class);
	    vs.disp();

	}

}
