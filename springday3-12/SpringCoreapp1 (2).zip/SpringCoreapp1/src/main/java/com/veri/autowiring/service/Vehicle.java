package com.veri.autowiring.service;

public interface Vehicle {
   void drive();

}
