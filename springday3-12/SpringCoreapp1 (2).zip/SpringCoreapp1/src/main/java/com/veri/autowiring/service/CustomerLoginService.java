package com.veri.autowiring.service;

import com.veri.autowiring.dto.CustomerLoginDTO;
import com.veri.autowiring.exception.InvalidUserException;

public interface CustomerLoginService {
	public String authenticateCustomer(CustomerLoginDTO customerLogin) throws InvalidUserException;
}
