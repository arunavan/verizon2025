package com.veri.autowiring.exception;

public class InvalidUserException extends Exception{
	public InvalidUserException(String message) {

		super(message);
	}

}
