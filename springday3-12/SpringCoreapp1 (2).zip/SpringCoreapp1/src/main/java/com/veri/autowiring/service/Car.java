package com.veri.autowiring.service;

import org.springframework.stereotype.Component;

@Component(value="c")
public class Car implements Vehicle{
	public void drive() {
		System.out.println("driving car ");
	}

}
