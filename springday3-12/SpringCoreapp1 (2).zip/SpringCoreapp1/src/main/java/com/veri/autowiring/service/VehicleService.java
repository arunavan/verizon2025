package com.veri.autowiring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehicleService {
	@Autowired
	//@Qualifier("c")
	Vehicle vehicle;
	
	void disp() {
		vehicle.drive();
	}

}
