package com.veri.autowiring.service;

import org.springframework.stereotype.Component;

@Component
public class Bus implements Vehicle{
	public void drive() {
		System.out.println("driving bus ");
	}

}
