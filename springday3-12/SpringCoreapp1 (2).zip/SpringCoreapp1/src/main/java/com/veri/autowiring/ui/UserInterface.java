package com.veri.autowiring.ui;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.env.Environment;

import com.veri.autowiring.configuration.SpringConfig;
import com.veri.autowiring.controller.CustomerLoginController;
import com.veri.autowiring.dto.CustomerLoginDTO;
import com.veri.autowiring.exception.InvalidUserException;

public class UserInterface {//tester,runner
	
	


	public static void main(String[] args) throws Exception {
		//ApplicationContext applicationContext =null;
		try{
			AnnotationConfigApplicationContext x= new AnnotationConfigApplicationContext(SpringConfig.class);
			CustomerLoginController customerLoginController = x.getBean(CustomerLoginController.class);
			CustomerLoginDTO customerLogin = new CustomerLoginDTO();
			customerLogin.setLoginName("harry");
			customerLogin.setPassword("harry123");

			String s=customerLoginController.authenticateCustomer(customerLogin);
			System.out.println(s);
		}catch(InvalidUserException exception){
			exception.getMessage();
		}

	}
}
