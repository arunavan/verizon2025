package com.veri.autowiring.service;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages ="com.veri.autowiring.service")
public class AppConfig {

}
