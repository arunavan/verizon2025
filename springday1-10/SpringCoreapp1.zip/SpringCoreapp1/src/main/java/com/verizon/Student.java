package com.verizon;

public class Student {
Integer id;
String name;
	public Student(Integer id, String name) {
		this.id=id;
		this.name=name;
	}

}
