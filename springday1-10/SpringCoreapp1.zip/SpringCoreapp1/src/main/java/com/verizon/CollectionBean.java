package com.verizon;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionBean {
    private List<String> list;
    private Set<String> set;
    private Map<String, String> map;
    private Properties props;

    // constructor
    public CollectionBean(List<String> list, Set<String> set, Map<String, String> map, Properties props) {
        this.list = list;
        this.set = set;
        this.map = map;
        this.props = props;
    }

    public void display() {
        System.out.println("List: " + list);
        System.out.println("Set: " + set);
        System.out.println("Map: " + map);
        System.out.println("Props: " + props);
    }
}