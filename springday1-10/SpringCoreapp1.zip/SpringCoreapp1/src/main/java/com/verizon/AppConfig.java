package com.verizon;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.*;

@Configuration
public class AppConfig {
	
	@Bean 
	public Student student() {
		return new Student(101,"Verizonuser");
	}

    @Bean
    public List<String> stringList() {
        return Arrays.asList("Java", "Spring", "Hibernate");
    }

    @Bean
    public Set<String> stringSet() {
        return new HashSet<>(Arrays.asList("Apple", "Banana", "Orange"));
    }

    @Bean
    public Map<String, String> stringMap() {
        Map<String, String> map = new HashMap<>();
        map.put("A", "Apple");
        map.put("B", "Ball");
        map.put("C", "Cat");
        return map;
    }

    @Bean
    public Properties properties() {
        Properties props = new Properties();
        props.setProperty("user", "admin");
        props.setProperty("password", "secret");
        return props;
    }

    @Bean
    public CollectionBean collectionBean(List<String> stringList, Set<String> stringSet,
                                         Map<String, String> stringMap, Properties properties) {
        return new CollectionBean(stringList, stringSet, stringMap, properties);
    }
}