package com.verizon;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        CollectionBean cb = context.getBean(CollectionBean.class);
        cb.display();
        Student st1=(Student)context.getBean("student");
        System.out.println(st1.name+"  "+st1.id);
    }
}