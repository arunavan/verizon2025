package com.verizon;

public class Account {
	

}
