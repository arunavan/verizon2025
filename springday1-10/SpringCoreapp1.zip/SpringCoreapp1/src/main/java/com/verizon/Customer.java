package com.verizon;

public class Customer {
	
	Integer id;
	String name;
	Customer(){
		
	}
	void start() {
		System.out.println(" object created");
	}
	void end() {
		System.out.println(" object destructed");
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
