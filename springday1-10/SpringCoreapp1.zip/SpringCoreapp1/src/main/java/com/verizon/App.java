package com.verizon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
      //  Customer c=new Customer();
      //  System.out.println(c.getId()+"  "+c.getName());
        //IOC container
        ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
        Customer c1=(Customer)context.getBean("c");
        Customer c2=(Customer)context.getBean("c");
        System.out.println(c1);
        System.out.println(c2);
        
         
        
    }
}
