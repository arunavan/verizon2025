package com.verizon.springmvc.controller;





import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ProductController {

	

	@RequestMapping("/product")
	public String message(@RequestParam("id") Integer id) {
		System.out.println("request param: "+id);
		return "home";
	}
	
	@RequestMapping("/product1/{id1}")
	public String message1(@PathVariable("id1") Integer id) {
		System.out.println("path param :"+id);
		return "home";
	}
	@GetMapping("/read")
	public String get() {
		System.out.println(" get- for read()");
		return "home";
	}
	@PostMapping("/add")
	public String add() {
		System.out.println(" post- for add()");
		return "home";
	}
	@PutMapping("/update")
	public String update() {
		System.out.println(" put- for update()");
		return "home";
	}
	@DeleteMapping("/delete")
	public String delete() {
		System.out.println(" delete- for delete()");
		return "home";
	}
	
	
}
