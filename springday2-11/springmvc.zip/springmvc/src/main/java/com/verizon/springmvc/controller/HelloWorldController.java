package com.verizon.springmvc.controller;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.verizon.springmvc.model.HelloWorld;


@Controller   //http://localhost:8080/springmvc/helloworld
public class HelloWorldController {

	@RequestMapping("/helloworld")
	public String handler(Model model) {
		
		HelloWorld helloWorld = new HelloWorld();
		helloWorld.setMessage("Welcome to SpringMVC session");
		helloWorld.setDateTime(LocalDateTime.now().plusHours(1).toString());
		model.addAttribute("helloWorld", helloWorld);
		return "helloworld1";
	}
	
	
	@RequestMapping("/home")  //http://localhost:8080/springmvc/home
	public String message() {
		return "home";
	}
	
	@RequestMapping("/welcome")  //http://localhost:8080/springmvc/home
	public String messageWeclome() {
		return "welcome";
	}
}